/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   geometry.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cshanda <cshanda@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/23 04:16:26 by cshanda           #+#    #+#             */
/*   Updated: 2021/11/19 01:27:15 by cshanda          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libfdf.h"

void	geom_pixel_put(t_data *data, t_point2D point)
{
	char	*dst;

	dst = data->addr + (point.b * data->line_length + point.a
			* (data->bits_per_pixel / 8));
	*(unsigned int *)dst = point.color;
}


#include <stdlib.h>

#include "libfdf.h"
#include "math.h"


double moveSpeed = 1;

void clearBuff(t_vars *vars)
{
	for(int y = 0; y < (int) vars->display.y; y++)
		for(int x = 0; x < (int)vars->display.x; x++)
			vars->buff[y][x] = 0;
}

void createTextyres(t_vars *vars)
{
	vars->texs = malloc(sizeof(Uint32)*8);
	if (!vars->texs)
		ft_assert("malloc err");
	for(int i = 0; i < 8; i++)
		vars->texs[i] = malloc(sizeof(Uint32)*texWidth * texHeight);//.resize();
		for(int x = 0; x < texWidth; x++)
			for(int y = 0; y < texHeight; y++)
			{
				int xorcolor = (x * 256 / texWidth) ^ (y * 256 / texHeight);
				//int xcolor = x * 256 / texWidth;
				int ycolor = y * 256 / texHeight;
				int xycolor = y * 128 / texHeight + x * 128 / texWidth;
				vars->texs[0][texWidth * y + x] = 65536 * 254 * (x != y && x != texWidth - y); //flat red texture with black cross
				vars->texs[1][texWidth * y + x] = xycolor + 256 * xycolor + 65536 * xycolor; //sloped greyscale
				vars->texs[2][texWidth * y + x] = 256 * xycolor + 65536 * xycolor; //sloped yellow gradient
				vars->texs[3][texWidth * y + x] = xorcolor + 256 * xorcolor + 65536 * xorcolor; //xor greyscale
				vars->texs[4][texWidth * y + x] = 256 * xorcolor; //xor green
				vars->texs[5][texWidth * y + x] = 65536 * 192 * (x % 16 && y % 16); //red bricks
				vars->texs[6][texWidth * y + x] = 65536 * ycolor; //red gradient
				vars->texs[7][texWidth * y + x] = 128 + 256 * 128 + 65536 * 128; //flat grey texture
			}
		// TODO:
		/*
		 #else
			//generate some textures
			unsigned long tw, th;
			loadImage(texture[0], tw, th, "pics/eagle.png");
			loadImage(texture[1], tw, th, "pics/redbrick.png");
			loadImage(texture[2], tw, th, "pics/purplestone.png");
			loadImage(texture[3], tw, th, "pics/greystone.png");
			loadImage(texture[4], tw, th, "pics/bluestone.png");
			loadImage(texture[5], tw, th, "pics/mossy.png");
			loadImage(texture[6], tw, th, "pics/wood.png");
			loadImage(texture[7], tw, th, "pics/colorstone.png");
		#endif
		 */
}
void main_(t_vars *vars)
{
	clearBuff(vars);

	double posX = vars->pozition.x;
	double posY = vars->pozition.y;
	double dirX = vars->dir.x, dirY = vars->dir.y; //initial direction vector
	double planeX = vars->plane.x, planeY = vars->plane.y; //the 2d raycaster version of camera plane

	for(int x = 0; x < (int)vars->display.x; x++)
	{
			//calculate ray position and direction
			double cameraX = 2 * x / (double)vars->display.x - 1; //x-coordinate in camera space
			double rayDirX = dirX + planeX*cameraX;
			double rayDirY = dirY + planeY*cameraX;

			//which box of the map we're in
			int mapX = (int)(posX);
			int mapY = (int)(posY);

			//length of ray from current position to next x or y-side
			double sideDistX;
			double sideDistY;

			//length of ray from one x or y-side to next x or y-side
			double deltaDistX = (rayDirX == 0) ? 1e30 : fabs(1 / rayDirX);
			double deltaDistY = (rayDirY == 0) ? 1e30 : fabs(1 / rayDirY);
			double perpWallDist;

			//what direction to step in x or y-direction (either +1 or -1)
			int stepX;
			int stepY;

			int hit = 0; //was there a wall hit?
			int side; //was a NS or a EW wall hit?

			//calculate step and initial sideDist
			if(rayDirX < 0)
			{
				stepX = -1;
				sideDistX = (posX - mapX) * deltaDistX;
			}
			else
			{
				stepX = 1;
				sideDistX = (mapX + 1.0 - posX) * deltaDistX;
			}
			if(rayDirY < 0)
			{
				stepY = -1;
				sideDistY = (posY - mapY) * deltaDistY;
			}
			else
			{
				stepY = 1;
				sideDistY = (mapY + 1.0 - posY) * deltaDistY;
			}
			//perform DDA
			while (hit == 0)
			{
				//jump to next map square, either in x-direction, or in y-direction
				if(sideDistX < sideDistY)
				{
					sideDistX += deltaDistX;
					mapX += stepX;
					side = 0;
				}
				else
				{
					sideDistY += deltaDistY;
					mapY += stepY;
					side = 1;
				}
				//Check if ray has hit a wall
				if(worldMap[mapX][mapY] > 0) hit = 1;
			}

			//Calculate distance of perpendicular ray (Euclidean distance would give fisheye effect!)
			if(side == 0) perpWallDist = (sideDistX - deltaDistX);
			else          perpWallDist = (sideDistY - deltaDistY);

			//Calculate height of line to draw on screen
			int lineHeight = (int)(vars->display.y / perpWallDist);


			int pitch = 100;

			//calculate lowest and highest pixel to fill in current stripe
			int drawStart = -lineHeight / 2 + vars->display.y / 2 + pitch;
			if(drawStart < 0) drawStart = 0;
			int drawEnd = lineHeight / 2 + vars->display.y / 2 + pitch;
			if(drawEnd >= (int)vars->display.y) drawEnd = vars->display.y - 1;

			//texturing calculations
			int texNum = worldMap[mapX][mapY] - 1; //1 subtracted from it so that texture 0 can be used!

			//calculate value of wallX
			double wallX; //where exactly the wall was hit
			if(side == 0) wallX = posY + perpWallDist * rayDirY;
			else          wallX = posX + perpWallDist * rayDirX;
			wallX -= floor((wallX));

			//x coordinate on the texture
			int texX = (int)(wallX * (double)(texWidth));
			if(side == 0 && rayDirX > 0) texX = texWidth - texX - 1;
			if(side == 1 && rayDirY < 0) texX = texWidth - texX - 1;

			// TODO: an integer-only bresenham or DDA like algorithm could make the texture coordinate stepping faster
			// How much to increase the texture coordinate per screen pixel
			double step = 1.0 * texHeight / lineHeight;
			// Starting texture coordinate
			double texPos = (drawStart - pitch - vars->display.y / 2 + lineHeight / 2) * step;
			for(int y = drawStart; y < drawEnd; y++)
			{
				// Cast the texture coordinate to integer, and mask with (texHeight - 1) in case of overflow
				int texY = (int)texPos & (texHeight - 1);
				texPos += step;
				Uint32 color = vars->texs[texNum][texHeight * texY + texX];
				//make color darker for y-sides: R, G and B byte each divided through two with a "shift" and an "and"
				if(side == 1) color = (color >> 1) & 8355711;
				vars->buff[y][x] = color;
			}
		}
		int i=0;
		int j;
		while(i < vars->display.y)
		{
			j=0;
			while(j < vars->display.x)
			{
				t_point2D p;
				p.a = j;
				p.b =i;
				p.color = vars->buff[i][j];
				geom_pixel_put(vars->img, p);
				j++;
			}
			i++;
		}
		//timing for input and FPS counter
		//oldTime = time;
		//time = getTicks();
		//double frameTime = (time - oldTime) / 1000.0; //frametime is the time this frame has taken, in seconds
		//printf("%i\n",1.0 / frameTime); //FPS counter
		//redraw();

		//speed modifiers
		//double moveSpeed = frameTime * 5.0; //the constant value is in squares/second
		//double rotSpeed = frameTime * 3.0; //the constant value is in radians/second


}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   util5.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cshanda <cshanda@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/28 18:06:37 by cshanda           #+#    #+#             */
/*   Updated: 2021/07/28 20:09:00 by cshanda          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libfdf.h"

void	close_pr(size_t size, int file, size_t *it)
{
	if (size <= 0)
	{
		close(file);
		ft_assert("File zero!");
	}
	(*it)--;
}

void	createHook(t_vars *vars)
{
	mlx_key_hook(vars->win, key_hook, vars);
	mlx_mouse_hook(vars->win, mous_hook, vars);
	mlx_hook(vars->win, 17, 1 << 17, close_prog17, vars);
	mlx_loop(vars->mlx);
}

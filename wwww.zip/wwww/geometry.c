/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   geometry.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cshanda <cshanda@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/23 04:16:26 by cshanda           #+#    #+#             */
/*   Updated: 2021/07/27 05:26:52 by cshanda          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libfdf.h"

void	geom_pixel_put(t_data *data, t_point2D point)
{
	char	*dst;

	dst = data->addr + (point.b * data->line_length + point.a
			* (data->bits_per_pixel / 8));
	*(unsigned int *)dst = point.color.int_color;
}

t_interval	create_inerval(t_point3D p1, t_point3D p2)
{
	t_interval	result;

	if (p2.a - p1.a < 0 || p2.b - p1.b < 0)
		ft_assert("!!p2.a - p1.a < 0 || p2.b - p1.b < 0)!!");
	if (p2.a - p1.a < p2.b - p1.b)
		StartEnd(&result, p1.b, p2.b);
	else
		StartEnd(&result, p1.a, p2.a);
	if (abs(result.start - result.end) < fabsf(p2.c - p1.c))
	{
		if (p2.c >= p1.c)
			StartEnd(&result, p1.c, p2.c);
		else
			StartEnd(&result, p2.c, p1.c);
	}
	return (result);
}

t_point3D	copy_point3D(t_point3D p1)
{
	t_point3D	point;

	point.a = p1.a;
	point.b = p1.b;
	point.c = p1.c;
	point.color.int_color = p1.color.int_color;
	point.color.r = p1.color.r;
	point.color.g = p1.color.g;
	point.color.b = p1.color.b;
	point.color.t = p1.color.t;
	return (point);
}

t_point3D	create_cof(t_point3D p1, t_point3D p2, t_interval interval)
{
	t_point3D	result;

	result.a = (float)(p2.a - p1.a) / (float)(interval.end - interval.start);
	result.b = (float)(p2.b - p1.b) / (float)(interval.end - interval.start);
	result.c = (float)(p2.c - p1.c) / (float)(interval.end - interval.start);
	return (result);
}

void	geom_line3D(t_data *data, t_point3D p1, t_point3D p2, t_pozition2D size)
{
	t_point3D	point;
	t_point3D	cof;
	t_point2D	point2;
	t_interval	interval;
	int			i;

	interval = create_inerval(p1, p2);
	cof = create_cof(p1, p2, interval);
	point = copy_point3D(p1);
	i = interval.start;
	while (i <= interval.end)
	{
		point2.color = point.color;
		toIsometric2D(point, &(point2));
		if (point2.a > 0 && point2.b > 0 && point2.a < (int)size.x
			&& point2.b < (int)size.y)
			geom_pixel_put(data, point2);
		point.a += cof.a;
		point.b += cof.b;
		if (p2.c != point.c)
			point.c += cof.c;
		i++;
	}
}

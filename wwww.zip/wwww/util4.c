/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   util4.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cshanda <cshanda@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/27 06:00:48 by cshanda           #+#    #+#             */
/*   Updated: 2021/07/28 19:00:59 by cshanda          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libfdf.h"

t_point2D	startPoint(t_vars *vars, size_t i, size_t j)
{
	t_point2D	sp;

	sp.a = (vars->offset.x + j) * vars->zoom.x;
	sp.b = (vars->offset.y + i) * vars->zoom.y;
	return (sp);
}

void	lineColor(t_vars *v, size_t i, size_t j)
{
	t_point3D	p[2];
	t_point2D	sp;

	if (j < (size_t)v->mass.param.max_x - 1)
	{
		sp = startPoint(v, i, j);
		p[0] = p3D(sp.a, sp.b, get_z(v, i, j), get_color(v, i, j));
		if (v->mass.param.iscolors == 1)
		{
			p[1] = p3D(sp.a + v->zoom.x, sp.b + v->zoom.y,
					   get_z(v, i + 1, j + 1), get_color(v, i + 1, j + 1));
			geom_line3D(v->img, p[0], p[1], v->mass.display);
		}
	}
}

int	zero(int *val)
{
	*val = -1;
	return (1);
}

void	StartEnd(t_interval *result, float start, float end)
{
	result->start = start;
	result->end = end;
}

void	init_m(t_val_mass *line_mas, int len)
{
	int		i;

	i = 0;
	while (i < len)
	{
		line_mas->val = 0;
		line_mas->color = 0;
		line_mas++;
		i++;
	}
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   util3.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cshanda <cshanda@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/27 03:43:04 by cshanda           #+#    #+#             */
/*   Updated: 2021/07/27 05:07:51 by cshanda          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libfdf.h"
#include "stdio.h"

int	no_dect(char *c)
{
	int	result;

	result = 0;
	while (*c)
	{
		if (!ft_isalnum(*c) && *c != '-')
			return (result);
		c++;
		result++;
	}
	return (0);
}

void	clear_masString(char **mass)
{
	size_t	i;

	i = 0;
	while (mass[i])
	{
		free(mass[i]);
		i++;
	}
	free(mass);
}

void	paramz(t_param_mass *param, int z)
{
	if (param->min_z > z)
		param->min_z = z;
	if (param->max_z < z)
		param->max_z = z;
}

void	ft_assert(char *err)
{
	size_t	i;

	i = 0;
	while (err[i])
	{
		write(1, &err[i], 1);
		i++;
	}
	exit(0);
}

void	ft_atoi_mas(char **mas_c, t_val_mass **mas_i, t_param_mass *param)
{
	long	i;
	char	**line_ar;

	i = 0;
	while (i < param->max_x)
	{
		if (!no_dect(mas_c[i]))
		{
			(*mas_i)[i].val = ft_atoi(mas_c[i]);
			(*mas_i)[i].color = 0xffffff;
		}
		else
		{
			if (*(mas_c[i] + no_dect(mas_c[i])) != ',')
				ft_assert("Found wrong line length. Exiting.\n");
			line_ar = ft_split(mas_c[i], ',');
			(*mas_i)[i].val = ft_atoi(line_ar[0]);
			(*mas_i)[i].color = ft_atoi16(line_ar[1]);
			clear_masString(line_ar);
			param->iscolors = 1;
		}
		paramz(param, (*mas_i)[i].val);
		i++;
	}
}

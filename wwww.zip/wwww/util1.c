/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   util1.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cshanda <cshanda@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/23 02:40:35 by cshanda           #+#    #+#             */
/*   Updated: 2021/08/01 20:03:53 by cshanda          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libfdf.h"
#include "printf.h"
void	init_param_mass(t_param_mass *param, size_t *it)
{
	param->min_x = 0;
	param->min_y = 0;
	param->min_z = 0;
	param->max_z = 0;
	param->max_x = 0;
	param->max_y = 0;
	*it = 0;
}

void	clear_mas2d(t_val_mass **mass, size_t size_y)
{
	size_t	i;

	i = 0;
	while (i < size_y)
	{
		free(mass[i]);
		i++;
	}
	free(mass);
}

void	auto_pozition(t_vars *vars)
{
	t_point3D	min_point3d;
	t_point3D	max_point3d;
	t_point2D	min_point2d;
	t_point2D	max_point2d;
	t_point2D	delta_point2d;

	min_point3d.a = vars->mass.param.min_x;
	min_point3d.b = vars->mass.param.min_y;
	min_point3d.c = vars->mass.param.min_z;
	max_point3d.a = vars->mass.param.max_x;
	max_point3d.b = vars->mass.param.max_y;
	max_point3d.c = vars->mass.param.max_z;
	toIsometric2D(min_point3d, &min_point2d);
	toIsometric2D(max_point3d, &max_point2d);
	delta_point2d.a = max_point2d.a - min_point2d.a;
	delta_point2d.b = max_point2d.b - min_point2d.b;
	vars->zoom.x = vars->delta.x / 3;
	vars->zoom.y = vars->delta.y / 3;
	vars->zoom.z = vars->delta.z / 3;
	if (vars->zoom.z < 0)
		vars->zoom.z *= -1;
	vars->offset.x = -1 * (int)vars->mass.display.x / vars->delta.x;
	vars->offset.y = -2 * vars->offset.x;
	vars->offset.z = 0;
}

t_vars	*create_vars(t_pozition2D d_size, char *path)
{
	t_vars	*vars;
	size_t	max;

	vars = malloc(sizeof(t_vars));
	vars->mass = get_mass(path);
	max = get_max(vars, d_size);
	vars->mass.display.x = d_size.x;
	vars->mass.display.y = d_size.y;
	vars->delta.x = max;
	vars->delta.y = max;
	vars->delta.z = max;
	auto_pozition(vars);
	vars->len.x = vars->mass.param.max_x;
	vars->len.y = vars->mass.param.max_y;
	vars->mlx = mlx_init();
	vars->win = mlx_new_window(vars->mlx, d_size.x, d_size.y, "fdf");
	vars->img = malloc(sizeof(t_data));
	vars->img->img = mlx_new_image(vars->mlx, d_size.x, d_size.y);
	vars->img->addr = mlx_get_data_addr(vars->img->img,
			&(vars->img->bits_per_pixel), &(vars->img->line_length),
			&(vars->img->endian));
	return (vars);
}

int	ft_atoi16(const char *nptr)
{
	size_t				i;
	unsigned long		result;
	unsigned long		resulttmp;
	int					pozitiv;

	if (*nptr == '\0' || nptr[1] != 'x')
		return (0);
	nptr++;
	nptr++;
	result = 0;
	pozitiv = 1;
	i = 0;
	while (nptr[i] < 33 && nptr[i] != '\e')
		++i;
	if (nptr[i] == '-' || nptr[i] == '+')
		pozitiv = 1 - 2 * (nptr[i++] == '-');
	while (inXEX(nptr[i]))
	{
		resulttmp = result;
		result = 16 * result + ofsetHEX(nptr[i]);
		if (resulttmp > result)
			return ((-1 - pozitiv) / 2);
		++i;
	}
	return (pozitiv * result);
}

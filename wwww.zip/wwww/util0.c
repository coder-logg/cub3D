/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   util0.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cshanda <cshanda@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/23 02:12:48 by cshanda           #+#    #+#             */
/*   Updated: 2021/08/01 20:18:50 by cshanda          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libfdf.h"
#include "stdio.h"
int	get_z(t_vars *vars, size_t i, size_t j)
{
	return (((int)vars->mass.mass[i][j].val + (int)vars->offset.z)
			* (int)vars->zoom.z);
}

int	get_color(t_vars *vars, size_t i, size_t j)
{
	return (vars->mass.mass[i][j].color);
}

void	create(t_vars *v)
{
	int			i;
	int			j;
	t_point3D	p[4];
	t_point2D	sp;

	i = 0;
	while (i < v->mass.param.max_y && zero(&j) && ++i)
	{
		while ((j++ || 1) && j < v->mass.param.max_x)
		{
			sp = startPoint(v, i - 1, j);
			p[0] = p3D(sp.a, sp.b, get_z(v, i - 1, j), get_color(v, i, j));
			p[1] = p3D(sp.a + v->zoom.x, sp.b, get_z(v, i - 1, j + 1),
					   get_color(v, i - 1, j + 1));
			if ((v->mass.param.max_y > i - 1))
				p[2] = p3D(sp.a, sp.b + v->zoom.y, get_z(v, i, j),
						   get_color(v, i, j));
			if ((v->mass.param.max_y > i - 1))
				geom_line3D(v->img, p[0], p[2], v->mass.display);
			if (j < v->mass.param.max_x - 1)
				geom_line3D(v->img, p[0], p[1], v->mass.display);
			lineColor(v, i - 1, j);
		}
	}
}

void	add_mass(char *lines, t_mass_data *mass_d, size_t it)
{
	char		**line_ar;

	line_ar = ft_split_size(lines, ' ', &(mass_d->param.max_x));
	mass_d->mass[it] = malloc(sizeof(t_val_mass *) * (mass_d->param.max_x + 1));
	init_m(mass_d->mass[it], mass_d->param.max_x + 1);
	ft_atoi_mas(line_ar, &(mass_d->mass[it]), &(mass_d->param));
	clear_masString(line_ar);
}

t_mass_data	get_mass(char *path)
{
	int			file;
	char		*lines;
	t_mass_data	mass_d;
	size_t		it;
	size_t		size;

	size = size_p(path);
	init_param_mass(&(mass_d.param), &it);
	mass_d.mass = malloc(sizeof(t_val_mass) * (size + 1));
	file = open(path, O_RDONLY);
	mass_d.param.iscolors = 0;
	mass_d.param.max_x = 0;
	while (get_next_line(file, &lines) && (it++ || 1))
	{
		add_mass(lines, &mass_d, it - 1);
		free(lines);
	}
	if (*lines != 0)
		add_mass(lines, &mass_d, it);
	else
		close_pr(size, file, &it);
	free(lines);
	mass_d.param.max_y = it;
	close(file);
	return (mass_d);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libfdf.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cshanda <cshanda@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/24 21:37:12 by cshanda           #+#    #+#             */
/*   Updated: 2021/11/18 00:34:02 by cshanda          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBFDF_H
# define LIBFDF_H
# include <stdlib.h>
# include <math.h>
# include <fcntl.h>
# include "mlx.h"
# include "libft/libft.h"
# include "gnl/libgnl.h"

typedef enum e_zoom_process
{
	increase = 1,
	reduce = -1
}					t_zoom_process;
typedef enum e_bool{
	false,
	true
} bool;
typedef struct s_data
{
	void			*img;
	char			*addr;
	int				bits_per_pixel;
	int				line_length;
	int				endian;
}					t_data;

typedef struct s_interval
{
	int				start;
	int				end;
}					t_interval;

typedef struct s_pozition3D
{
	float			x;
	float			y;
	float			z;
}					t_pozition3D;

typedef struct s_pozition2D
{
	size_t			x;
	size_t			y;
}					t_pozition2D;

typedef struct s_color
{
	unsigned char	t;
	unsigned char	r;
	unsigned char	g;
	unsigned char	b;
	int				int_color;
}					t_color;

typedef struct s_point2D
{
	int				a;
	int				b;
	t_color			color;
}					t_point2D;

typedef struct s_param_mass
{
	int				min_x;
	int				min_y;
	int				min_z;
	int				max_x;
	int				max_y;
	int				max_z;
	int				iscolors;
}					t_param_mass;

typedef struct s_val_mass
{
	int				val;
	int				color;
}					t_val_mass;

typedef struct s_mass_data
{
	t_val_mass		**mass;
	t_param_mass	param;
	t_pozition2D	display;
}					t_mass_data;

typedef struct s_vars
{
	void			*mlx;
	void			*win;
	t_data			*img;
	t_pozition3D	zoom;
	t_pozition2D	len;
	t_pozition3D	offset;
	t_pozition3D	delta;
	t_mass_data		mass;
}					t_vars;

typedef struct s_point3D
{
	float			a;
	float			b;
	float			c;
	t_color			color;
}				t_point3D;

typedef struct s_paramfync
{
	t_pozition3D	*zoom;
	t_pozition3D	*offset;
	t_mass_data		*mass_data;

}				t_paramfync;
void		geom_pixel_put(t_data *data, t_point2D point);
int			close_prog(int keycode, t_vars *vars);
int			close_prog17(int keycode, t_vars *vars);
void		geom_line3D(t_data *data, t_point3D p1, t_point3D p2,
				t_pozition2D size);
void		create(t_vars *vars);
int			key_hook(int keycode, t_vars *vars);
int			mous_hook(int button, int x, int y, t_vars *vars);
void		init_param_mass(t_param_mass *param, size_t *it);
size_t		size_p(char *path);
t_mass_data	get_mass(char *path);
void		zoom(t_pozition3D *z, t_zoom_process process, t_pozition3D cof);
t_point3D	copy_point3D(t_point3D p1);
int			toIsometric2D(t_point3D point, t_point2D *p_out);
void		clear_mas2d(t_val_mass **mass, size_t size_y);
void		clear_masString(char **mass);
t_vars		*create_vars(t_pozition2D d_size, char *path);
void		auto_pozition(t_vars *vars);
int			ft_atoi16(const char *nptr);
size_t		get_max(t_vars *vars, t_pozition2D d_size);
int			inXEX(char c);
int			ofsetHEX(char c);
t_point3D	p3D(int x, int y, int z, int color);
void		paramz(t_param_mass *param, int z);
void		ft_assert(char *err);
int			no_dect(char *c);
void		ft_atoi_mas(char **mas_c, t_val_mass **mas_i, t_param_mass *param);
t_point2D	startPoint(t_vars *vars, size_t i, size_t j);
int			zero(int *val);
int			get_z(t_vars *vars, size_t i, size_t j);
int			get_color(t_vars *vars, size_t i, size_t j);
void		lineColor(t_vars *vars, size_t i, size_t j);
void		StartEnd(t_interval *result, float start, float end);
void		init_m(t_val_mass *line_mas, int len);
void		close_pr(size_t size, int file, size_t *it);
void		createHook(t_vars *var);

void main_(t_vars *vars);
#endif

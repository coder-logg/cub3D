/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   util2.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cshanda <cshanda@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/27 02:32:05 by cshanda           #+#    #+#             */
/*   Updated: 2021/06/29 06:59:16 by cshanda          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libfdf.h"

size_t	get_max(t_vars *vars, t_pozition2D d_size)
{
	size_t	max;

	if (d_size.x >= d_size.y && d_size.x >= cos(2.0944)
		* ((float)(vars->mass.param.max_z - vars->mass.param.min_z)))
		max = d_size.x / vars->mass.param.max_x;
	if (d_size.y > d_size.x && d_size.x >= sin(2.0944)
		* ((float)(vars->mass.param.max_z - vars->mass.param.min_z)))
		max = d_size.y / vars->mass.param.max_y;
	if (d_size.y > d_size.x && d_size.x < sin(2.0944)
		* ((float)(vars->mass.param.max_z - vars->mass.param.min_z))
		&& d_size.y < sin(2.0944) * ((float)(vars->mass.param.max_z
		- vars->mass.param.min_z)))
		max = d_size.y / sin(2.0944) * (float)(vars->mass.param.max_z
				- vars->mass.param.min_z);
	return (max);
}

int	inXEX(char c)
{
	int		result;

	result = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f')
		|| (c >= 'A' && c <= 'F');
	return (result);
}

int	ofsetHEX(char c)
{
	int		result;

	if (c >= '0' && c <= '9')
		result = c - '0';
	if (c >= 'a' && c <= 'f')
		result = 10 + c - 'a';
	if (c >= 'A' && c <= 'F')
		result = 10 + c - 'A';
	return (result);
}

size_t	size_p(char *path)
{
	int			file;
	char		*lines;
	size_t		i;

	i = 0;
	file = open(path, O_RDONLY);
	if (file == -1)
		ft_assert("File open error.\n");
	while (get_next_line(file, &lines))
	{
		free(lines);
		i++;
	}
	free(lines);
	close(file);
	return (i);
}

t_point3D	p3D(int x, int y, int z, int color)
{
	t_point3D	point;

	point.a = (float)(x);
	point.b = (float)(y);
	point.c = (float)(z);
	point.color.int_color = color;
	return (point);
}

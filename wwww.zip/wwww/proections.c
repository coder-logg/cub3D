/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   proections.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cshanda <cshanda@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/23 05:42:23 by cshanda           #+#    #+#             */
/*   Updated: 2021/06/25 21:31:29 by cshanda          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libfdf.h"

int	toIsometric2D(t_point3D point, t_point2D *p_out)
{
	p_out->a = (point.a + point.b) / sqrt(2);
	p_out->b = (-point.a + point.b - sqrt(2) * point.c) / sqrt(6);
	return (0);
}
